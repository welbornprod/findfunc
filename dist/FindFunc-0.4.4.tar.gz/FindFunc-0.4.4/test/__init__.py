""" Tests for FindFunc.
    -Christopher Welborn 4-9-17
"""
